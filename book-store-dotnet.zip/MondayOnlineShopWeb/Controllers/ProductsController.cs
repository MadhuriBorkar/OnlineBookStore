﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace MondayOnlineShopWeb.Controllers
{
    public class ProductsController : Controller
    {
        public ActionResult Index()
        {
            List<Books> allProducts = BusinessManager.GetAllProducts();
            ViewData["allProducts"] = allProducts;
            return View();
        }
        public ActionResult Inventory()
        {
            List<Books> allProducts = BusinessManager.GetAllProducts();
            ViewData["allProducts"] = allProducts;
            return View();
        }
        public ActionResult Details(int id)
        {
            Books theProduct = BusinessManager.GetProduct(id);
            return View(theProduct);
        }
        public ActionResult Insert()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Insert(int id, string title, string description,
                                   double unitprice,int quantity, string imageurl)
        {
            Books newProduct = new Books
            {
                ID = id,
                Title = title,
                Description = description,
                UnitPrice = unitprice,
                Quantity = quantity,
                ImageUrl = imageurl
            };

            bool status= BusinessManager.Insert(newProduct);
            if (status)
            {
                this.RedirectToAction("index", "products");
            }
            return View();
        }
    }
}