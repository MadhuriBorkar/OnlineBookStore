﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace MondayOnlineShopWeb.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            if (username == "teju" && password == "coco")
            {
                return this.RedirectToAction("index", "Admin");
            }
            return View();
            /*Customer theCustomer = BusinessManager.login(username, password);

            Session["username"] = theCustomer.Name;
            Session["password"] = theCustomer.Password;



             //TempData["mydata"] = theCustomer;

            if (theCustomer.Name == "Tejaswi Shivaji Vanjari" && theCustomer.Password == "abcd")
            {
                
                    return this.RedirectToAction("index", "Admin");
               
            }
            else
            {
                return this.RedirectToAction("login", "accounts");
            }



            return View();*/

        }


        [ActionName("Register")]
        public ActionResult Register_Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Register")]
        public ActionResult Register_Post( string name, string gender,
                                   int age, string location, string phonenumber, string role, string email, string password)
        {

            Customer newCustomer = new Customer
            {
                
                Name = name,
                Gender = gender,
                Age = age,
                Location = location,
                PhoneNumber = phonenumber,
                Role = role,
                Email = email,
                Password = password
            };



            bool status = BusinessManager.Insert(newCustomer);
            if (status)
            {

                return RedirectToAction("login", "accounts");
            }

            return View();
        }
        public ActionResult Logout()
        {
            Cart theExistingCart = this.Session["shoppingcart"] as Cart;
            theExistingCart.items.Clear();
            return RedirectToAction("index", "home");
        }
    }
}

