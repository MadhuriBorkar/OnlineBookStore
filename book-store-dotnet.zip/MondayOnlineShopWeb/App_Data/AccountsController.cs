﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
namespace MondayOnlineShopWeb.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
           
            return View();

        }


        [ActionName("Register")]
        public ActionResult Register_Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Register")]
        public ActionResult Register_Post(Customer customer)
        {
            //var customer = new Customer();
            TryValidateModel(customer);
            if (ModelState.IsValid)
            {
                //Insert new customer using Business Manager insert method
                return RedirectToAction("login", "accounts");
            }

            return View();
        }
    }
}