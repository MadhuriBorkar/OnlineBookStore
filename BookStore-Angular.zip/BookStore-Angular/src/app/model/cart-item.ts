import { Book } from "./Book";

export class CartItem {
    id: number;
    name: string;
    picByte: string;
    price: number;
    quantity: number;
    retrievedImage: string;
    constructor(book: Book){
        this.id=book.id;
        this.name=book.name;
        this.picByte=book.picByte;
        this.price=book.price;
        this.retrievedImage=book.retrievedImage;
        this.quantity=1;

    }
}
